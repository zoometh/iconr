## ---- fig.width=6, fig.height=4, echo=FALSE------------------------------
library(FuzzyLandscapes)
x <- seq(0,100,1)
curve(fl_trapezoid(x,p1=30,p2=60,p3=120,p4=130),from=0,to=100,
      xlab = "Speed (km/h)",
      ylab = "Membership degree",
      lwd=2,
      col="blue")
legend("topleft",lty=1,lwd=2,col="blue","High speed")


## ----libraries,message=FALSE,warning=FALSE-------------------------------
library(raster)
library(sf)
library(FuzzyLandscapes)
library(dplyr)
library(rasterVis)

## ---- fig.width=6, fig.height=4,message=FALSE----------------------------
# The data set give the locations of 1000 seismic events of MB > 4.0. The events occurred in a cube near Fiji since 1964.
data(quakes)

# Spatialisation of the dataset
library(sf)
quakes <- st_as_sf(quakes, coords = c("long", "lat"),crs = 4326) %>%
  st_transform("+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=20026376 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext  +no_defs") #3857 + Different central meridian

strong_quakes <- quakes[quakes$mag>=6,]
weak_quakes <- quakes[quakes$mag<6,]

# Creation of a raster, based on the Spatial locations of the earthquakes
calc_dist <- function(quakes,extent_object){
  dista <- rasterize(quakes, 
                     raster(nrows=200, 
                            ncols=200, 
                            xmn=min(st_coordinates(extent_object)[,1]), 
                            xmx=max(st_coordinates(extent_object)[,1]), 
                            ymn=min(st_coordinates(extent_object)[,2]), 
                            ymx=max(st_coordinates(extent_object)[,2]), 
                            crs=CRS(("+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=20026376 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext  +no_defs"))))
  dista <- !is.na(dista)[[1]]
  
  # Calculating the distance to the earthquakes locations
  dista <- gridDistance(dista,origin=1)
}

dista_strong <- calc_dist(strong_quakes,quakes)  
dista_weak <- calc_dist(weak_quakes,quakes)  

plotstack <- stack(dista_strong,dista_weak)
names(plotstack) <- c("dista_strong","dista_weak") 

plot(plotstack)
rm(plotstack)

## ----Fuzzyfication, fig.width=6, fig.height=4----------------------------
library(FuzzyLandscapes)
strong_too_close <- fl_create_ras(method="bell",
                                  rast = dista_strong,
                                  p1 = 0.00002, 
                                  p2=1, 
                                  p3 = 0.0003, 
                                  p4 = 0, 
                                  setname = "strong_too_close")

plot_fs(strong_too_close)

strong_medium_distance <- fl_create_ras(method="triangle",
                                  rast = dista_strong,
                                  p1 = 5e+05, 
                                  p2=1e+06, 
                                  p3 = 2e+06, 
                                  p4 = 0, 
                                  setname = "strong_medium_distance")

plot_fs(strong_medium_distance)

strong_far_away <- fl_create_ras(method="trapezoid",
                                  rast = dista_strong,
                                  p1 = 1.5e+06, 
                                  p2=1.7e+06, 
                                  p3 = 4e+06, 
                                  p4 = 5e+06, 
                                  setname = "strong_far_away")

plot_fs(strong_far_away)

plot_fs_comb(strong_too_close,
             strong_medium_distance,
             strong_far_away)

## ----Fuzzyfication2, fig.width=6, fig.height=4---------------------------
weak_too_close <- fl_create_ras(method="trapezoid",
                                  rast = dista_weak,
                                  p1 = -10, 
                                  p2=0, 
                                  p3 = 2.6e+05, 
                                  p4 = 4e+05, 
                                  setname = "weak_too_close")

#plot_fs(weak_too_close)

weak_medium_distance <- fl_create_ras(method="trapezoid",
                                  rast = dista_weak,
                                  p1 = 2e+05, 
                                  p2=5e+05, 
                                  p3 = 8e+05, 
                                  p4 = 1e+06, 
                                  setname = "weak_medium_distance")

#plot_fs(weak_medium_distance)

weak_far_away <- fl_create_ras(method="bell",
                                  rast = dista_weak,
                                  p1 = 0.0002, 
                                  p2=1, 
                                  p3 = 0.0001, 
                                  p4 = 1.5e+06, 
                                  setname = "weak_far_away")

#plot_fs(weak_far_away)

plot_fs_comb(weak_too_close,
             weak_medium_distance,
             weak_far_away,
             ltys=c(2,3,4),
             cols = colorRampPalette(c("green", "red","blue")))

## ----Rules,message=FALSE-------------------------------------------------
library(dplyr)
ruleda <- tribble(
  ~Val1,                 ~Op1,  ~Val2,                   ~Op2,  ~Result,
  "weak_too_close",      "and", "strong_too_close",      "then","way_too_close",
  "weak_too_close",      "and", "strong_medium_distance","then","at_least_not_strong",
  "weak_medium_distance","and", "strong_too_close",      "then","way_too_close",
  "weak_too_close",      "and", "strong_far_away",       "then","at_least_not_strong",
  "weak_medium_distance","and", "strong_far_away",       "then","seems_ok",
  "weak_far_away",       "and", "strong_medium_distance","then","seems_ok",
  "weak_far_away",       "and", "strong_far_away",       "then","save_location"
)

## ----ApplyRules,message=FALSE--------------------------------------------
fuzzystack <- fl_frbs_stack(strong_too_close,strong_medium_distance,strong_far_away,
                            weak_too_close,weak_medium_distance,weak_far_away,
                            rules = ruleda,
                            result_intersect = TRUE,
                            defuzzification = unique(as.character(ruleda$Result)),
                            defuzzification_method = "zadeh")

## ----ApplyRule,message=FALSE---------------------------------------------
way_too_close <- fl_combine_fuzzy(weak_too_close,strong_too_close, combinator="and", newname = "way_too_close")

str(way_too_close)

## ---- fig.width=6, fig.height=6.3,message=FALSE--------------------------
raster::plot(fuzzystack$FuzzyResults,nc = 2)

## ---- fig.width=6, fig.height=6,message=FALSE----------------------------
library(rasterVis)
r <- as.factor(fuzzystack$Defuzzification$`DefuzzifedRaster`)
rat <- levels(r)[[1]]
rat[["defuzzy"]] <- c(as.character(fuzzystack$Defuzzification$Legend$Long)[rat$ID])
levels(r) <- rat
levelplot(r, 
          col.regions=colorRampPalette(c("brown1","orange","yellow","limegreen"))(dim(rat)[1]))

