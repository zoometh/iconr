library(testthat)
library(FuzzyLandscapes)

test_check("FuzzyLandscapes")
