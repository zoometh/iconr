globalVariables(c("x")) ## necessary for the curve plots

##' Creation of bell shaped fuzzy set
##'
##' This function creates a fuzzy set with a bell shaped outline
##' @title fl_bell
##' @return a fuzzy set
##' @author Wolfgang Hamer, Daniel Knitter
##' @param x input data
##' @param p1 the "belliness" of the bell
##' @param p2 the height of the bell (default 1)
##' @param p3 the standard deviation of the bell
##' @param p4 the center of the bell, i.e. where the bell has the values p2
##' @export fl_bell
##' @examples
##' curve(fl_bell(x,.001,1,1,50),from=0,to=100)
fl_bell <- function(x, p1 = 0.001 , p2 = 1, p3, p4){
  fs_bell <- p2 * exp(-p3^2 * p1 * (x - p4)^2)
  return(fs_bell)
}

##' Creation of unfuzzy fuzzy set
##'
##' This function creates a fuzzy set with a crisp input
##' @title fl_crisp
##' @return a fuzzy set
##' @author Wolfgang Hamer, Daniel Knitter
##' @param x input data
##' @param p1 the crisp value to be given out
##' @export fl_crisp
##' @examples
##' curve(fl_bell(x,.001,1,1,50),from=0,to=100)
fl_crisp <- function(x, p1){
  fs_crisp <- ifelse(x == p1, 1, 0)
  return(fs_crisp)
}

##' Create a triangle fuzzy set
##'
##' This functions creates a triangle fuzzy set
##' @title fl_triangle
##' @param x input data
##' @param p1 the start of the triangle
##' @param p2 the center of the triangle, where the membership is 0
##' @param p3 the end of the triangle
##' @return a fuzzy set
##' @author Wolfgang Hamer, Daniel Knitter
##' @export fl_triangle
##' @examples
##' p1=20
##' p2=40
##' p3=50
##' x <- seq(0,100,1)
##'
##' curve(fl_triangle(x,p1=-1,p2=20,p3=40),from=0,to=100)
fl_triangle <- function(x, p1, p2, p3){
 fs_triangle <- ifelse(x <= p1 | x >= p3, 0,
                       ifelse(x > p1 & x < p2, (x - p1) / (p2 - p1),
                              ifelse(x == p2, 1, (p3 - x) / (p3 - p2)
                                     )
                              )
                       )
 return(fs_triangle)
}

##' Create a trapezoidal fuzzy set
##'
##' This functions creates a trapezoidal fuzzy set
##' @title fl_trapozoid
##' @param x input data
##' @param p1 the start of the trapezoid
##' @param p2 the beginning of the part of the trapezoid where the membership degree is one
##' @param p3 the end of the part of the trapezoid where the membership degree is one
##' @param p4 the end of the trapezoid
##' @return a fuzzy set
##' @author Wolfgang Hamer, Daniel Knitter
##' @export fl_trapezoid
##' @examples
##' x <- seq(0,100,1)
##' curve(fl_trapezoid(x,p1=-1,p2=0,p3=20,p4=60),from=0,to=100)
fl_trapezoid <- function(x, p1, p2, p3, p4){
 fs_trapezoid <- ifelse(x <= p1 | x >= p4, 0,
                        ifelse(x > p1 & x < p2, (x - p1) / (p2 - p1),
                               ifelse(x >= p2 & x <= p3, 1, (p4 - x) / (p4 - p3)
                                      )
                               )
                        )
 return(fs_trapezoid)
}


