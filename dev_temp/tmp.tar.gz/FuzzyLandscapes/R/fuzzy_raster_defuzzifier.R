##' Defuzzify a stack of fuzzified rasters
##'
##' This function is conducts an defuzzification of a fuzzified raster stack
##' @title fl_defuzzify_stack
##' @param fuzzified_stack a raster stack as created by fl_apply_rules
##' @param defuzzification_method default = "zadeh"; the defuzzification method used to create a final crisp set
##' @return a raster stack
##' @importFrom dplyr mutate_if
##' @export fl_defuzzify_stack
fl_defuzzify_stack <- function(fuzzified_stack,
                               defuzzification_method = "zadeh"){
  if (defuzzification_method == "zadeh") {
    fuzzified_stack <- zadeh(fuzzified_raster = fuzzified_stack)      
    names(fuzzified_stack)[nlayers(fuzzified_stack)] <- "Defuzzification"
    defuzzified_list <- list(DefuzzifedRaster = fuzzified_stack[["Defuzzification"]],
                             Legend = data.frame(ID = c(1:(nlayers(fuzzified_stack) - 1)),
                                                 Long = c(names(fuzzified_stack)[1:(nlayers(fuzzified_stack)-1)])))
    return(defuzzified_list)
  } else {
  print("No appropriate defuzzification selected!")
  }

}

##' Defuzzifcation after Zadeh
##'
##' the defuzzifcation after Zadeh takes the maximum of the different fuzzified raster
##' @title zadeh
##' @param fuzzified_raster the frbs raster stack
##' @return a rasterstack
zadeh <- function(fuzzified_raster){
  zadeh_stack <- raster::stack(fuzzified_raster,
                               raster::which.max(fuzzified_raster))
  return(zadeh_stack)
}
