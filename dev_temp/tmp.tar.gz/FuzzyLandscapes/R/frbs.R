##' Analyse a fuzzy rule based system using raster data
##'
##' This function is the all-in-one approach to conduct the fuzzy analyses on raster. It takes a dataframe of rules as input, fuzzifies the different parameter raster and conducts an optional defuzzification (currently based on Mamdani)
##' @title fl_frbs_stack
##' @param ... several lists containing the raster and fuzzy function information as created by fl_create_ras
##' @param rules a data.frame of the fuzzy rules that integrate the different fuzzy sets. The columns of the data.frame are:
##' \enumerate{
##'   \item \strong{Val1} the first element of the rule, i.e. a fuzzy set
##'   \item \strong{Op1} the operator connecting Val1 and Val2
##'   \item \strong{Val2} the second element of the rule,, i.e. a fuzzy set
##'   \item \strong{Op2} the operator connecting Val2 and Val3
##'   \item \strong{Val3} the third element of the rule,, i.e. a fuzzy set
##'   \item \strong{Op3} the consequences operator "then"
##'   \item \strong{Result} the name of the resulting fuzzy raster
##' }
##' @param result_intersect default = TRUE; in case you have more than one rule that defines a result combine the corresponding raster using "max"
##' @param defuzzification default = all; select those raster from the rules "result" column that should be used for defuzzification. This is useful when you define fuzzy raster that are an input for another raster (see vignette for an example)
##' @param defuzzification_method default = "zadeh"; the defuzzification method used to create a final crisp set
##' @return a raster stack
##' @importFrom dplyr mutate_if
##' @export fl_frbs_stack
##' @examples
##' 
##' # Creation of example data
##' set.seed(1234)
##' testraster1 <- raster(nrows=50, ncols=50)
##' testraster1[] <- runif(n=50*50, min = 0, max = 100)
##' testraster2 <- testraster1
##' testraster1[] <- testraster1[]*(coordinates(testraster1)[,1]+50)/150
##' testraster1[][which(testraster1[]<0)] <- 0
##' testraster2[] <- testraster2[]*(coordinates(testraster2)[,2]+50)/250
##' 
##' test11fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster1,
##'                            p1 = 25,
##'                            p2 = 125,
##'                            p3 = 175,
##'                            p4 = 200,
##'                            setname = "fuzzified_test_11") 
##' test12fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster1,
##'                            p1 = 0,
##'                            p2 = 25,
##'                            p3 = 75,
##'                            p4 = 100,
##'                            setname = "fuzzified_test_12")
##' plot_fs_comb(test11fuzzy,test12fuzzy) 
##' 
##' test2fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster2,
##'                            p1 = 0,
##'                            p2 = 10,
##'                            p3 = 50,
##'                            p4 = 60,
##'                            setname = "fuzzified_test_2") 
##' # Define Rules
##' library(dplyr)
##' ruleda <- tribble(
##'   ~Val1,              ~Op1,  ~Val2,              ~Op2,  ~Result,
##'  "fuzzified_test_11", "and", "fuzzified_test_2", "then","ResultFuzzy1",
##'  "fuzzified_test_12", "and", "fuzzified_test_2", "then","ResultFuzzy2"
##' )

##' # Combining several fuzzy rasters 
##' combined_raster <- fl_frbs_stack(test11fuzzy,test12fuzzy,test2fuzzy,
##'                                     rules = "ruleda")
##' 
##' plot(combined_raster$`FuzzyResults`)
##' plot(combined_raster$Defuzzification$`DefuzzifedRaster`)

fl_frbs_stack <- function(...,
                          rules,
                          result_intersect = TRUE,
                          defuzzification = "all",
                          defuzzification_method = "zadeh"){

  fuzzified_stack <- fl_apply_rules(...,rules = rules, result_intersect = result_intersect)

  
    
  if(defuzzification[1] == "all") {
    defuzz_list <- fl_defuzzify_stack(fuzzified_stack = fuzzified_stack,
                                          defuzzification_method = defuzzification_method)
    fuzzified_stack <- list(FuzzyResults = fuzzified_stack,
                            Defuzzification = defuzz_list)
  } else if(all(is.element(defuzzification, names(fuzzified_stack)))) {
    defuzz_list <- fl_defuzzify_stack(fuzzified_stack = fuzzified_stack[[defuzzification]],
                                          defuzzification_method = defuzzification_method)
    fuzzified_stack <- list(FuzzyResults = fuzzified_stack,
                            Defuzzification = defuzz_list)
    } else {
    print("No appropriate defuzzification selected!")
  }
  
  return(fuzzified_stack)
}

##' Apply fuzzy rules on raster data
##'
##' This function is the all-in-one approach to conduct the fuzzy analyses on raster. It takes a dataframe of rules as input, fuzzifies the different parameter raster and conducts an optional defuzzification (currently based on Mamdani)
##' @title fl_apply_rules
##' @param ... several lists containing the raster and fuzzy function information as created by fl_create_ras
##' @param rules a data.frame of the fuzzy rules that integrate the different fuzzy sets. The columns of the data.frame are:
##' \enumerate{
##'   \item \strong{Val1} the first element of the rule, i.e. a fuzzy set
##'   \item \strong{Op1} the operator connecting Val1 and Val2
##'   \item \strong{Val2} the second element of the rule,, i.e. a fuzzy set
##'   \item \strong{Op2} the operator connecting Val2 and Val3
##'   \item \strong{Val3} the third element of the rule,, i.e. a fuzzy set
##'   \item \strong{Op3} the consequences operator "then"
##'   \item \strong{Result} the name of the resulting fuzzy raster
##' }
##' @param result_intersect default = TRUE; in case you have more than one rule that defines a result combine the corresponding raster using "max"
##' @return a raster stack
##' @importFrom dplyr mutate_if
##' @export fl_apply_rules
##' @examples
##' 
##' # Creation of example data
##' set.seed(1234)
##' testraster1 <- raster(nrows=50, ncols=50)
##' testraster1[] <- runif(n=50*50, min = 0, max = 100)
##' testraster2 <- testraster1
##' testraster1[] <- testraster1[]*(coordinates(testraster1)[,1]+50)/150
##' testraster1[][which(testraster1[]<0)] <- 0
##' testraster2[] <- testraster2[]*(coordinates(testraster2)[,2]+50)/250
##' 
##' test11fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster1,
##'                            p1 = 25,
##'                            p2 = 125,
##'                            p3 = 175,
##'                            p4 = 200,
##'                            setname = "fuzzified_test_11") 
##' test12fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster1,
##'                            p1 = 0,
##'                            p2 = 25,
##'                            p3 = 75,
##'                            p4 = 100,
##'                            setname = "fuzzified_test_12")
##' plot_fs_comb(test11fuzzy,test12fuzzy) 
##' 
##' test2fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster2,
##'                            p1 = 0,
##'                            p2 = 10,
##'                            p3 = 50,
##'                            p4 = 60,
##'                            setname = "fuzzified_test_2") 
##' # Define Rules
##' library(dplyr)
##' ruleda <- tribble(
##'   ~Val1,              ~Op1,  ~Val2,              ~Op2,  ~Result,
##'  "fuzzified_test_11", "and", "fuzzified_test_2", "then","ResultFuzzy1",
##'  "fuzzified_test_12", "or",  "ResultFuzzy1",     "then","ResultFuzzy2"
##' )

##' # Combining several fuzzy rasters 
##' combined_raster <- fl_apply_rules(test11fuzzy,test12fuzzy,test2fuzzy,
##'                                     rules = "ruleda")
##' 
##' plot(combined_raster)


fl_apply_rules <- function(...,
                          rules,
                          result_intersect = TRUE){
  
  if(any(is.na(rules))) {
    stop("There are NA's in the rules data.frame", call. = FALSE)
  }
  if(!is.element(result_intersect,c(TRUE,FALSE))){
      stop("result_intersect needs to be either TRUE or FALSE!", call. = FALSE)
  }

 
  FuzzyRasterLists <- list(...)
  
  if(any(lengths(FuzzyRasterLists)!=6)){
    stop(paste("The",which(lengths(FuzzyRasterLists)!=6),"th element you gave me is not as created by the fl_create_ras function! "), call. = FALSE)
  }
 
  fuzzified_stack <- stack(Map(function(x){x$FuzzyRaster},FuzzyRasterLists))       
  names(fuzzified_stack) <- unlist(Map(function(x){x$Setname},FuzzyRasterLists))
  
  ## change operators to lower case
  rules <- dplyr::mutate_if(rules, startsWith(colnames(rules), "Op"), tolower)
  
  ## change factor to character
  rules <- dplyr::mutate_if(rules, is.factor, as.character)
  
  #  fuzzy_sets_df[,"layer"] <- layer_index
  n_fuzzified_raster <- length(names(fuzzified_stack))  
  
  ## check whether some of the results are also part of the rules
  for(i in 1:dim(rules)[1]) {
    if(any(is.element(t(rules[i, -dim(rules)[2]]), rules[, dim(rules)[2]]))) {
      if(i < max(which(is.element(rules[, dim(rules)[2]], t(rules[i,-dim(rules)[2]]))))){
        rules <- rbind(rules[-i,],rules[i,])
      }
    }  
    
    newr <- stack(fuzzified_stack[[as.character(rules[i,1])]])
    names(newr) <- "newr"
    if(dim(rules)[2] - length(grep("Op", names(rules)))>2){
      for(j in seq(from = 3,
                   to = dim(rules)[2] - 2,
                   by = 2)) {      
        if(rules[i, j - 1] == "and"){
          newr <- min(newr, fuzzified_stack[[as.character(rules[i, j])]])        
        } else if(rules[i, j - 1] == "or"){
          newr <- max(newr, fuzzified_stack[[as.character(rules[i, j])]])
        } else if(rules[i, j - 1] == ""){
          # In case of no more operators do nothing     
        } else {
          print(paste("Unknown operator", rules[i, j + 1]))
        }
        gc()
      }
    }
    if(result_intersect == FALSE | i == 1) {
      fuzzified_stack <- raster::stack(fuzzified_stack, newr)
      actname <- rules[i, dim(rules)[2]]
      names(fuzzified_stack)[i + n_fuzzified_raster] <- actname
    } else {
      actname <- rules[i, dim(rules)[2]]
      # If "result"-raster has been generated before
      if(is.element(actname, names(fuzzified_stack))){
        # check which previously created "result"-raster have the same name
        duplf <- which(names(fuzzified_stack) == as.character(actname))[1]
        # take the maximum of the two equally named "result"-raster
        fuzzified_stack[[duplf]] <- max(fuzzified_stack[[duplf]], newr)
        names(fuzzified_stack)[duplf] <- actname
      } else {
        fuzzified_stack <- raster::stack(fuzzified_stack, newr)
        names(fuzzified_stack)[nlayers(fuzzified_stack)] <- actname
      }
    }
  }
  return(fuzzified_stack[[(n_fuzzified_raster+1):dim(fuzzified_stack)[3]]])
}
    


#' Combine different fuzzified raster dataset lists
#'
#' @title fl_combine_fuzzy
#' @param ... several lists containing the raster and fuzzy function information as created by fl_create_ras
#' @param combinator a character string defining the kind of combination:
#' \enumerate{
#'   \item \strong{"and"} the minimum of the raster sets is returned
#'   \item \strong{"or"} the maximum of the raster sets is returned
#' }
#' @param newname option do name the resulting fuzzy set (default: NA) 
#'
#' @return a list containing the combined "FuzzyRaster", the user-defined "Setname", the fuzzy rasters the combination is "Based on" and the used "Combinator" 
#' @export
#' @examples
#' 
#' # Creation of example data
#' set.seed(1234)
#' testraster1 <- raster(nrows=50, ncols=50)
#' testraster1[] <- runif(n=50*50, min = 0, max = 100)
#' testraster2 <- testraster1
#' testraster1[] <- testraster1[]*(coordinates(testraster1)[,1]+50)/150
#' testraster1[][which(testraster1[]<0)] <- 0
#' testraster2[] <- testraster2[]*(coordinates(testraster2)[,2]+50)/250
#' 
#' test1fuzzy <-fl_create_ras(method = "trapezoid",
#'                            rast = testraster1,
#'                            p1 = 25,
#'                            p2 = 125,
#'                            p3 = 175,
#'                            p4 = 200,
#'                            setname = "fuzzified_test_1") 
#' 
#' test2fuzzy <-fl_create_ras(method = "trapezoid",
#'                            rast = testraster2,
#'                            p1 = 0,
#'                            p2 = 10,
#'                            p3 = 50,
#'                            p4 = 60,
#'                            setname = "fuzzified_test_2") 
#'
#' # Combining several fuzzy rasters 
#' combined_raster <- fl_combine_fuzzy(test1fuzzy,test2fuzzy,
#'                                     combinator = "and",
#'                                     newname = "combined_raster")
#' 
#' plot_fs(combined_raster)


fl_combine_fuzzy <- function(...,
                             combinator,
                             newname = NA){
  FuzzyRasterListe <- list(...)
  
  if(length(FuzzyRasterListe)==1){
    if(class(FuzzyRasterListe[[1]])=="RasterStack"){
      FuzzyRasterListe <- as.list(FuzzyRasterListe[[1]])
    }else if(class(FuzzyRasterListe[[1]])=="list"){
      tryit <- try(class(FuzzyRasterListe[[1]][[1]]$`FuzzyRaster`)=="RasterLayer",silent=TRUE)
      if(tryit==TRUE){
        FuzzyRasterListe <- FuzzyRasterListe[[1]]
      }else{
        stop("Input object is identified as single list, which does not consist of several FuzzyRasterLists. Check the input!")
      }
    }
  }
  
  
  if(class(FuzzyRasterListe[[1]])=="RasterLayer"){
    FuzzyRasterListe[[1]] <- list(FuzzyRaster = FuzzyRasterListe[[1]],
                                  Setname = names(FuzzyRasterListe[[1]]))
  }
  
  newr <- stack(FuzzyRasterListe[[1]]$`FuzzyRaster`)

  names(newr) <- "newr"
  for(j in seq(from = 2,
               to = length(FuzzyRasterListe),
               by = 1)) {
    if(class(FuzzyRasterListe[[j]])=="RasterLayer"){
      FuzzyRasterListe[[j]] <- list(FuzzyRaster = FuzzyRasterListe[[j]],
                                    Setname = names(FuzzyRasterListe[[j]]))
    }
    
    if(combinator == "and"){
      newr <- min(newr, FuzzyRasterListe[[j]]$`FuzzyRaster`)
        
    } else if(combinator == "or"){
      newr <- max(newr, FuzzyRasterListe[[j]]$`FuzzyRaster`)
    } else {
      print(paste("Unknown operator"))
    }
    gc()
  }
  names(newr) <- newname
  
  resulte <- list(FuzzyRaster = newr,
                  Setname = newname,
                  Basedon = unlist(Map(function(x){x$Setname},FuzzyRasterListe)),
                  Combinator = combinator)
  return(resulte)
}



