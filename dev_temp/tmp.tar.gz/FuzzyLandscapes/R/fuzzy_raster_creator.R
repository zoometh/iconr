##' Create a fuzzy-set raster
##'
##' This functions creates a fuzzy set raster based on different shaped membership functions to be selected by the user
##' @title fl_create_ras
##' @param method one of "triangle" (default), "trapezoid", "gauss"
##' @param rast the input raster
##' @param p1 see fl_bell, fl_triangle* or fl_trapezoid*
##' @param p2 see fl_bell, fl_triangle* or fl_trapezoid*
##' @param p3 see fl_bell, fl_triangle* or fl_trapezoid*
##' @param p4 see fl_bell, fl_triangle* or fl_trapezoid*
##' @param setname option do name the resulting fuzzy set (default: NA)
##' @return a fuzzy set raster
##' @import grDevices graphics
##' @export fl_create_ras
##' @author Wolfgang Hamer, Daniel Knitter
##' @examples
##' 
##' # Creation of example data
##' set.seed(1234)
##' testraster1 <- raster(nrows=50, ncols=50)
##' testraster1[] <- runif(n=50*50, min = 0, max = 100)
##' testraster1[] <- testraster1[]*(coordinates(testraster1)[,1]+50)/150
##' testraster1[][which(testraster1[]<0)] <- 0
##'
##' # Creation of two fuzzy-set rasters
##' test1fuzzy <-fl_create_ras(method = "triangle",
##'                            rast = testraster1,
##'                            p1 = 25,
##'                            p2 = 125,
##'                            p3 = 175,
##'                            p4 = NA,
##'                            setname = "fuzzified_test_1") 
##' 
##' test2fuzzy <-fl_create_ras(method = "trapezoid",
##'                            rast = testraster1,
##'                            p1 = -1,
##'                            p2 = 0,
##'                            p3 = 50,
##'                            p4 = 70,
##'                            setname = "fuzzified_test_2") 
##' 
##' plot_fs(test1fuzzy)
##' plot_fs_comb(test1fuzzy,test2fuzzy)

fl_create_ras <- function(method = "triangle",
                          rast,
                          p1 = NA,
                          p2 = NA,
                          p3 = NA,
                          p4 = NA,
                          setname = NA) {

  if (!(method %in% c("triangle", "trapezoid", "bell", "crisp"))) {
    stop(paste("Method ", method, " unknown. Please select a valid method!"),
         call. = FALSE)
  }
  
  if (method == "triangle") {
    if (any(is.na(c(p1, p2, p3)))) {
      print(paste("p1, p2, and p3 are required. Check if all are set correct"))
    } else {
      newgri <- fl_triangle_r(x = rast, p1 = p1, p2 = p2, p3 = p3)      
    }
  }

  if (method == "trapezoid"){
    if(any(is.na(c(p1, p2, p3, p4)))){
      print(paste("p1, p2, p3, and p4 are required. Check if all are set correct"))
    } else {
      newgri <- fl_trapezoid_r(x = rast, p1 = p1, p2 = p2, p3 = p3, p4 = p4)            
    }
  }

  if (method == "bell"){
    if(any(is.na(c(p1, p2, p3, p4)))){
      print(paste("p1, p2, p3, and p4 are required. Check if all are set correct"))
    } else {
      newgri <- fl_bell(x = rast, p1, p2, p3, p4)            
    }
  }

  if (method == "crisp"){
    if(any(is.na(c(p1)))){
      print(paste("p1 is required. Check if all are set correct"))
    } else {
      newgri <- fl_crisp_r(x = rast, p1)            
    }
  } 
  
  if (exists("newgri")) {
    newgrili <- list(FuzzyRaster = newgri,
                     FuzzyMethod = method,
                     FuzzificationRules = c(p1 = p1,
                                            p2 = p2,
                                            p3 = p3,
                                            p4 = p4),
                     Setname = setname,
                     NameOriginal = deparse(substitute(rast)), 
                     RangeOriginal = c(min = min(raster::values(rast),na.rm = TRUE),
                                       max = max(raster::values(rast),na.rm = TRUE)))
    return(newgrili)
  }
  }


##' Plot a fuzzy-set raster
##'
##' This functions plots a fuzzy set raster and the additional memebership function
##' @title plot_fs
##' @param FuzzyRasterList a list containing the raster and fuzzy function information as created by fl_create_ras
##' @param xyrange a vector containing minimum and maximum value of x axis of the MF plot; if NA as default the range values of the input raster are used
##' @return a plot
##' @import grDevices graphics
##' @export plot_fs
##' @author Wolfgang Hamer, Daniel Knitter
##' @examples
##' 
##' # See example of fl_create_ras

plot_fs <- function(FuzzyRasterList, 
                    xyrange = NA,
                    cols = colorRampPalette(c("#fef0d9","#fdcc8a","#fc8d59","#d7301f")),
                    ...) {
  fun <- FuzzyRasterList$FuzzyMethod
  newgri <- FuzzyRasterList$FuzzyRaster
  p1 <- FuzzyRasterList$FuzzificationRules["p1"]
  p2 <- FuzzyRasterList$FuzzificationRules["p2"]
  p3 <- FuzzyRasterList$FuzzificationRules["p3"]
  p4 <- FuzzyRasterList$FuzzificationRules["p4"]
  
  if(is.na(xyrange)){
    xyrange = c(FuzzyRasterList$RangeOriginal["min"],FuzzyRasterList$RangeOriginal["max"])
  }

  prepar <- par()$mfrow
  if(is.null(fun)){
    raster::plot(newgri, breaks = seq(0,1,.1),
                 col = cols(11))
    }else{
      par(mfrow = c(1,2))
      raster::plot(newgri, breaks = seq(0,1,.1),
                   col = cols(11))
    
    if(fun == "triangle") {    
      plot(NA,
           xlim=c(min(xyrange),max(xyrange)),
           xlab = FuzzyRasterList$NameOriginal,
           ylim=c(0,1),
           ylab="Membership degree")
      lines(x=c(min(xyrange)-10,p1, p2, p3,max(xyrange)+10),
            y=c(0,0,1,0,0))
    }
    
    if(fun == "trapezoid") {   
      plot(NA,
           xlim=c(min(xyrange),max(xyrange)),
           xlab = FuzzyRasterList$NameOriginal,
           ylim=c(0,1),
           ylab="Membership degree")
      lines(x=c(min(xyrange)-10,p1, p2, p3, p4,max(xyrange)+10),
            y=c(0,0,1,1,0,0))
    }
    
    if(fun == "crisp") {
      curve(fl_crisp(x, p1),
            from = min(xyrange),
            to = max(xyrange),
            xlab = FuzzyRasterList$NameOriginal,
            ylab = "Membership degree")
    }
    
    if(fun == "bell") {
      par(mfrow = c(1,2))
      raster::plot(newgri, breaks = seq(0,1,.1),
                   col = cols(11))
      curve(fl_bell(x, p1, p2, p3, p4),
            from = min(xyrange),
            to = max(xyrange),
            xlab = FuzzyRasterList$NameOriginal,
            ylab = "Membership degree")
    }
  }
  par(mfrow=prepar)
}






##' Plot several fuzzy sets in one plot
##'
##' This functions plots several memebership function in one plot
##' @title plot_fs_comb
##' @param ... several lists containing the raster and fuzzy function information as created by fl_create_ras
##' @param cols a colorRampPalette defining which colours to use for the different fuzzy sets
##' @param xyrange a vector containing minimum and maximum value of x axis of the MF plot; if NA as default the range values of the input raster are used
##' @param logic should a logical connection ("and","or") be considered? (default: NA) 
##' @param ltys a vector containing the linetype codes (1 for bold, 2 for dashed, ...); inf "default" all lines are bold
##' @return a plot
##' @import grDevices graphics ggplot2
##' @export plot_fs_comb
##' @author Wolfgang Hamer, Daniel Knitter
##' @examples
##' 
##' # See example of fl_create_ras

plot_fs_comb <- function(..., 
                         cols = colorRampPalette(c("sienna1","lightblue1","green")),
                         xyrange = NA,
                         logic = NA,
                         ltys = "default") {
  FuzzyRasterLists <- list(...)
  
  if(class(FuzzyRasterLists[[1]])=="list"){
    tryit <- try(class(FuzzyRasterLists[[1]][[1]]$`FuzzyRaster`)=="RasterLayer",silent=TRUE)
    if(tryit==TRUE){
      FuzzyRasterLists <- FuzzyRasterLists[[1]]
    }
  }
  
  elements <- length(lengths(FuzzyRasterLists))
  colrange <- cols(elements)
  
  if(ltys[1] == "default"){
    ltys <- rep(1,elements)
  }
  
  if(any(is.na(xyrange))){
    xyrange = range(do.call(rbind,Map(function(x){x$RangeOriginal},
                                      x = FuzzyRasterLists)))
  }
  
  setnam <- c(unlist(Map(function(x){x$Setname}, FuzzyRasterLists)))
  
  plotme <-list()
  
  
  for(i in 1:elements){
    FuzzyRasterList <- FuzzyRasterLists[[i]]
    fun <- FuzzyRasterList$FuzzyMethod
    p1 <- FuzzyRasterList$FuzzificationRules["p1"]
    p2 <- FuzzyRasterList$FuzzificationRules["p2"]
    p3 <- FuzzyRasterList$FuzzificationRules["p3"]
    p4 <- FuzzyRasterList$FuzzificationRules["p4"]
    
    if(fun == "triangle") {    
      plotme[[i]] <- data.frame(x=c(xyrange[1]-diff(c(xyrange[1], p1))-diff(xyrange),p1, p2, p3,xyrange[2]+diff(c(xyrange[2], p3))+diff(xyrange)),
                                y=c(0,0,1,0,0),
                                Fuzzyset=setnam[i])
    }
    
    if(fun == "trapezoid") {   
      plotme[[i]] <- data.frame(x=c(xyrange[1]-diff(c(xyrange[1], p1))-diff(xyrange),p1, p2, p3, p4,xyrange[2]+diff(c(xyrange[2], p4))+diff(xyrange)),
                                y=c(0,0,1,1,0,0),
                                Fuzzyset=setnam[i])
    }
    
    if(fun == "crisp") {
      x=seq(from=xyrange[1],to=xyrange[2],length=100)
      plotme[[i]] <- data.frame(x=x,
                                y=fl_crisp(x, p1),
                                Fuzzyset=setnam[i])
    }
    
    if(fun == "bell") {
      x=seq(from=xyrange[1],to=xyrange[2],length=100)
      plotme[[i]] <- data.frame(x=x,
                                y=fl_bell(x, p1, p2, p3, p4),
                                Fuzzyset=setnam[i])
    }
    
  }
  
  
  plotme <- ggplot2::fortify(do.call(rbind.data.frame, plotme))
  
  if(is.na(logic)){
    ggplot(data=plotme,aes(x=x,y=y))+
      geom_line(size=1,aes(colour=Fuzzyset,linetype=Fuzzyset)) +
      theme_bw() +
      coord_cartesian(xlim = c(xyrange[1], xyrange[2])) +
      scale_color_manual(values=colrange) +
      scale_linetype_manual(values=ltys) +
      labs(x = "") +
      labs(y = "Membership Degree")
  }else if(logic=="or"){
    ggplot(data=plotme,aes(x=x,y=y)) +
      geom_polygon(aes(group = Fuzzyset), alpha = 1) +
      theme_bw() +
      coord_cartesian(xlim = c(xyrange[1], xyrange[2])) +
      scale_linetype_manual(values=ltys) + 
      labs(x = "") +
      labs(y = "Membership Degree")
  }else if(logic=="and"){
    ggplot(data=plotme,aes(x=x,y=y)) +
      geom_polygon(aes(group = Fuzzyset), alpha = 0.3) +
      theme_bw() +
      coord_cartesian(xlim = c(xyrange[1], xyrange[2])) +
      scale_linetype_manual(values=ltys) + 
      labs(x = "") +
      labs(y = "Membership Degree")
  }else if(logic=="both"){
    ggplot(data=plotme,aes(x=x,y=y)) +
      geom_polygon(aes(group = Fuzzyset), alpha = 0.3) +
      theme_bw() +
      coord_cartesian(xlim = c(xyrange[1], xyrange[2])) +
      scale_linetype_manual(values=ltys) + 
      labs(x = "") +
      labs(y = "Membership Degree")
  }
  
  
}




