if(F){
library(raster)
wag_el=raster("E:/Scales of Transformation/Data_Structure/1_Raster/DGM10_Wagrien_trim.tif")

wag_rivd=raster("E:/Scales of Transformation/Data_Structure/1_Raster/River_Dist.tif")

library(rgdal)
#SAGA Channel Network (Strahler >1)
river <- readOGR(dsn = "E:/Scales of Transformation/Data_Structure/3_Vectors/Flow_Stuff", layer = "clipstrahler")
river <- spTransform(river, projection(wag_el))
#subset of relevant data
bwag=as(extent(wag_el), "SpatialPolygons")
proj4string(bwag) <- projection(wag_el)
river=river[bwag,]
#writeOGR(river, "E:/Scales of Transformation/Data_Structure/3_Vectors/Flow_Stuff","clipstrahler2", driver="ESRI Shapefile")

river.r=rasterize(river,wag_el)
river.dist=distance(river.r)

#writeRaster(river.dist, filename="E:/Scales of Transformation/Data_Structure/1_Raster/DGM10_Wagrien_trim_ridi.tif", format="GTiff", overwrite=F)

}
if(F){

wag_el=raster("E:/Scales of Transformation/Data_Structure/1_Raster/DGM10_Wagrien_trim.tif")
river.dist=raster("E:/Scales of Transformation/Data_Structure/1_Raster/DGM10_Wagrien_Calculations/grass_strahler_streamdist.tif")
pccurve=raster("E:/Scales of Transformation/Data_Structure/1_Raster/DGM10_Wagrien_Calculations/grass_pcurv2_smooth.tif")

ras <- stack(wag_el,river.dist,pccurve)
names(ras)=c("elev","dist","pccurve")
library(FuzzyLandscapes)

mindis=min(ras[["dist"]][],na.rm=TRUE)
maxdis=max(ras[["dist"]][],na.rm=TRUE)


curve(fl_gauss(x,p1=.0005,p2=1,p3=.2,p4=0),
      from=mindis,to=maxdis,lwd=2,col="#91bfdb")
curve(fl_triangle(x,p1=0,p2=550,p3=1000),
      from=mindis,to=maxdis,add=TRUE,lwd=2,col="#7fbf7b")
curve(fl_trapezoid(x,p1=500,p2=1000,p3=maxdis,p4=maxdis+1),
      from=mindis,to=maxdis,xlab="",ylab="Membership Degree",lwd=2,col="#fc8d59",add=TRUE)


minpc=min(ras[["pccurve"]][],na.rm=TRUE)
maxpc=max(ras[["pccurve"]][],na.rm=TRUE)


curve(fl_gauss(x,p1=1,p2=1,p3=100,p4=0),
      from=minpc,to=maxpc,lwd=2,col="#91bfdb")
curve(fl_gauss(x,p1=1,p2=1,p3=100,p4=minpc),
      from=minpc,to=maxpc,lwd=2,col="#91bfdb",add=T)
curve(fl_gauss(x,p1=1,p2=1,p3=100,p4=maxpc),
      from=minpc,to=maxpc,lwd=2,col="#91bfdb",add=T)



testm <- data.frame(
  name=c("short_dist","medium_dist","long_dist","flat","depression","summit"),
  method=c("gauss","triangle","trapezoid","gauss","gauss","gauss"),
  layer=c("dist","dist","dist","pccurve","pccurve","pccurve"),
  p1=c(.0005,0,500,1,1,1),
  p2=c(1,550,1000,1,1,1),
  p3=c(.2,1000,maxdis,100,100,100),
  p4=c(0,0,maxdis+1,0,minpc,maxpc))
testm

ruleda <- data.frame(
  Val1 = c("short_dist","short_dist","medium_dist","long_dist"),
  Op1 = c("and","and","",""),
  Val2 = c("flat","depression","",""),
  Op4 = "then",
  Result = c("high_settlement_probability", "medium_settlement_probability", "medium_settlement_probability","low_settlement_probability" ))
ruleda

fuzzystack <- fl_frbs_stack(fuzzyfication = testm,
                            rasterstack = ras,
                            rules = ruleda,
                            defuzzification = unique(as.character(ruleda$Result)),
                            combrules = TRUE)
plot(fuzzystack)

}
