##' Creation of bell shaped fuzzy set
##'
##' This function creates a fuzzy set with a bell shaped outline
##' @title fl_bell
##' @return a fuzzy set
##' @author Wolfgang Hamer, Daniel Knitter
##' @param x input data
##' @param p1 the "belliness" of the bell
##' @param p2 the height of the bell (default 1)
##' @param p3 the standard deviation of the bell
##' @param p4 the center of the bell, i.e. where the bell has the values p2
##' @export fl_bell
##' @examples
##' curve(fl_bell(x,.001,1,1,50),from=0,to=100)
fl_bell_r<- function(x, p1 = 0.001 , p2 = 1, p3, p4){
  fs_bell <- p2 * exp(-p3^2 * p1 * (x - p4)^2)
  return(fs_bell)
}

##' Creation of unfuzzy fuzzy set using a raster
##'
##' This function creates a fuzzy set raster with a crisp input
##' @title fl_crisp_r
##' @return a fuzzy set raster
##' @author Wolfgang Hamer, Daniel Knitter
##' @param x input raster
##' @param p1 the crisp value to be given out
##' @export fl_crisp_r
##' @examples
##' curve(fl_bell(x,.001,1,1,50),from=0,to=100)
fl_crisp_r <- function(x, p1){
  return(x == p1)
}

##' Create a triangle fuzzy set using a raster
##'
##' This functions creates a raster based on the application of a triangle fuzzy set
##' @title fl_triangle_r
##' @param x input data of class `raster`
##' @param p1 the start of the triangle
##' @param p2 the center of the triangle, where the membership is 0
##' @param p3 the end of the triangle
##' @return a raster
##' @author Wolfgang Hamer, Daniel Knitter
##' @export fl_triangle_r
##' @examples
##' tmp <- raster::raster(ncol = 100, nrow = 100)
##' raster::values(tmp) <- runif(raster::ncell(tmp), min = 10, max = 100)
##' raster::plot(fl_triangle_r(x = tmp,p1 = 40, p2 = 50,p3 = 70))
fl_triangle_r <- function(x, p1, p2, p3){
  if(p1 == p2) {
    p1 <- p1 - .1
  }
  if(p2 == p3) {
    p3 <- p3 + .1
  }
 e2 <- (x > p1 & x < p2) * ((x - p1) / (p2 - p1))
 e3 <- (x > p2 & x < p3) * ((p3 - x) / (p3 - p2))
 e4 <- (x == p2)
 fs_triangle_r <- e2 + e3 + e4
 return(fs_triangle_r)
}

##' Create a trapezoidal fuzzy set using a raster
##'
##' This functions creates a raster based on the application of a trapezoidal fuzzy set
##' @title fl_triangle_r
##' @param x input data of class `raster`
##' @param p1 the start of the trapezoid
##' @param p2 the beginning of the part of the trapezoid where the membership degree is one
##' @param p3 the end of the part of the trapezoid where the membership degree is one
##' @param p4 the end of the trapezoid
##' @return a raster
##' @author Wolfgang Hamer, Daniel Knitter
##' @export fl_trapezoid_r
##' @examples
##' tmp <- raster::raster(ncol = 100, nrow = 100)
##' raster::values(tmp) <- runif(raster::ncell(tmp), min = 10, max = 100)
##' raster::plot(fl_trapezoid_r(x = tmp, 40, 50, 70, 90))
fl_trapezoid_r <- function(x, p1, p2, p3, p4){
  if(p1 == p2) {
    p1 <- p1 - .1
  }
  if(p3 == p4) {
    p4 <- p4 + .1
  }
 e2 <- (x > p1 & x < p2) * ((x - p1) / (p2 - p1))
 e3 <- (x > p3 & x < p4) * ((p4 - x) / (p4 - p3))
 e4 <- (x >= p2 & x <= p3)
 fs_trapezoid_r <- e2 + e3 + e4
 return(fs_trapezoid_r)
}
