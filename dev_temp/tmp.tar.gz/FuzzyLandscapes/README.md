# FuzzyLandscapes

The goal of this package is the:

- Fuzzification of crisp raster data
- Rule-based combination of fuzzy datasets
- Defuzzification of those combined datasets


### Citation

Hopefully soon this citation will be completed

> Hamer, W. B. & Knitter, D. (2018). *FuzzyLandscapes*. 


### Installation

You can install FuzzyLandscapes from gitlab with:

```r
if(!require('devtools')) install.packages('devtools')
devtools::install_git('https://gitlab.com/CRC1266-A2/FuzzyLandscapes.git')
```

