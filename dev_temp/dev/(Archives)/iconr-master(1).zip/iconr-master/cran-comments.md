This is a new release

## Test environments
* local Windows 8 install, R 4.0.3
* win-builder (devel and release)
* ubuntu 16.04 (on travis-ci), R 4.0.2

## R CMD check results

0 errors | 0 warnings | 0 note

## Downstream dependencies

There are currently no downstream dependencies for this package
