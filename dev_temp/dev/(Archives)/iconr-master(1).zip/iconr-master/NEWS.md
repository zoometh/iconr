# Version 1.0.0 (December 2020)
First official CRAN release.
